#pragma once

class Error_Lp {

public:
	
	double result;
	double sum;
	double Lp(int p, double **x, double **y, int n);

};