#include "Error(Lp).h"
#include <iostream>
#include <cmath>
using namespace std;

double Error_Lp::Lp(int p, double **pArray1, double **pArray2, int n) {
	//p : the number of error
	//n : the number of node


	result = 0.0;
	sum = 0.0;
	int i,j;

	if (!p) cout << "Error! p is not netural number!" << endl;
		

	switch (p) {
	case 1:
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
				sum = sum + abs(pArray1[i][j] - pArray2[i][j]);
			}
		}

		result = sum / n;
		break;

	case 2:
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
				sum = sum + pow(abs(pArray1[i][j] - pArray2[i][j]), 2);
			}
		}

		result = sqrt(sum / n);
		break;
	}

	
	
	return result;
}