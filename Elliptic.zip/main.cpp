#include <iostream>
#include <cmath>
#include <fstream>
#include <ctime>
#include "Error(Lp).h"
using namespace std;

#define PI 3.1415926535897932384626433832795028841971

int main() {

	ofstream fout_T("out_T.dat");

	int i, j;

	const int nx = 20;							//The number of grid step in x direction
	const int ny = 40;							//The number of grid step in y direction
	double Lx = 1.0;							//Length in x direction
	double Ly = 2.0;							//Length in y direction
	double del_x = Lx / (double)nx;				//The grid size in x direction
	double del_y = Ly / (double)ny;				//The grid size in y direction
	cout << "del_x = " << del_x << endl;
	cout << "del_y = " << del_y << endl << endl;
	double beta = del_x / del_y;

	double **T;									//The main dependent variable at k iteration
	double **TN;								//The main dependent variable at k+1 iteration
	T = new double*[nx + 1];
	TN = new double*[nx + 1];
	for (i = 0; i < nx + 1; i++) {
		T[i] = new double[ny + 1];
		TN[i] = new double[ny + 1];
	}



	double w = 1.0;								//The relaxation parameter
	cout << "The relaxation parameter(w) : " << w << endl;

	double e = 1.0;								//Residual norm
	double eps = 0.00001;						//Residual norm criterion
	cout << "Residual norm criterion(eps) : " << eps << endl << endl;

	Error_Lp error;
	int k = 0;
	int print_step = 100;						//Print step(cout)
	double A, B;


	//Initialization
	for (i = 0; i < nx + 1; i++) {
		for (j = 0; j < ny + 1; j++) {
			T[i][j] = 0.0;
			TN[i][j] = 0.0;
		}
	}

	int nc = 0;
	cout << "Choose the number of scheme(1:Jacobi, 2:PGS, 3:PSOR)>>";
	cin >> nc;


	switch (nc) {
	case 1:

		//Calculation
		while (e > eps) {

			//Boundary condition
			j = 0;
			for (i = 1; i < nx; i++) {
				TN[i][j] = 100.;
			}


			i = 0;
			for (j = 0; j < ny + 1; j++) {
				TN[i][j] = 0.0;
			}


			i = nx;
			for (j = 0; j < ny + 1; j++) {
				TN[i][j] = 0.0;
			}


			j = nx;
			for (i = 1; i < nx; i++) {
				TN[i][j] = 0.0;
			}

			//Inner node
			for (i = 1; i < nx; i++) {
				for (j = 1; j < ny; j++) {
					TN[i][j] = 1.0 / (2.0*(1.0 + pow(beta, 2))) * (T[i - 1][j] + T[i + 1][j] + pow(beta, 2)*(T[i][j - 1] + T[i][j + 1]));
				}
			}


			//Update
			e = error.Lp(2, T, TN, nx + 1);
			for (i = 0; i < nx + 1; i++) {
				for (j = 0; j < ny + 1; j++) {
					T[i][j] = TN[i][j];
				}
			}

			//Print
			if (k%print_step == 0) {
				cout << "[k = " << k << "] L2 error(e) : " << e << endl;
			}

			//Update iteration number
			k++;
		}
		break;
	case 2:

		while (e > eps) {

			//Boundary condition
			j = 0;
			for (i = 1; i < nx; i++) {
				TN[i][j] = 100.;
			}


			i = 0;
			for (j = 0; j < ny + 1; j++) {
				TN[i][j] = 0.0;
			}


			i = nx;
			for (j = 0; j < ny + 1; j++) {
				TN[i][j] = 0.0;
			}


			j = nx;
			for (i = 1; i < nx; i++) {
				TN[i][j] = 0.0;
			}

			//Inner node
			for (i = 1; i < nx; i++) {
				for (j = 1; j < ny; j++) {
					TN[i][j] = 1.0 / (2.0*(1.0 + pow(beta, 2))) * (TN[i - 1][j] + T[i + 1][j] + pow(beta, 2)*(TN[i][j - 1] + T[i][j + 1]));
				}
			}





			//Update
			e = error.Lp(2, T, TN, nx + 1);
			for (i = 0; i < nx + 1; i++) {
				for (j = 0; j < ny + 1; j++) {
					T[i][j] = TN[i][j];
				}
			}

			//Print
			if (k%print_step == 0) {
				cout << "[k = " << k << "] L2 error(e) : " << e << endl;
			}

			//Update iteration number
			k++;



		}
		break;
	case 3:

		while (e > eps) {

			//Boundary condition
			j = 0;
			for (i = 1; i < nx; i++) {
				TN[i][j] = 100.;
			}


			i = 0;
			for (j = 0; j < ny + 1; j++) {
				TN[i][j] = 0.0;
			}


			i = nx;
			for (j = 0; j < ny + 1; j++) {
				TN[i][j] = 0.0;
			}


			j = nx;
			for (i = 1; i < nx; i++) {
				TN[i][j] = 0.0;
			}

			//Inner node
			for (i = 1; i < nx; i++) {
				for (j = 1; j < ny; j++) {
					TN[i][j] = (1.0 - w)*T[i][j] + w / (2.0*(1.0 + pow(beta, 2))) * (TN[i - 1][j] + T[i + 1][j] + pow(beta, 2)*(TN[i][j - 1] + T[i][j + 1]));
				}
			}






			//Update
			e = error.Lp(2, T, TN, nx + 1);
			for (i = 0; i < nx + 1; i++) {
				for (j = 0; j < ny + 1; j++) {
					T[i][j] = TN[i][j];
				}
			}

			//Print
			if (k%print_step == 0) {
				cout << "[k = " << k << "] L2 error(e) : " << e << endl;
			}

			//Update iteration number
			k++;

		}
		break;

	}



	//Print
	fout_T << "variables = X Y T" << endl;
	fout_T << "zone i=" << nx + 1 << " j=" << ny + 1 << endl;
	for (j = 0; j < ny + 1; j++) {
		for (i = 0; i < nx + 1; i++) {
			fout_T << i << "\t" << j << "\t" << T[i][j] << endl;
		}
	}


	cout << endl;
	cout << "Done!" << endl;
	cout << "Residual norm : " << e << endl;
	cout << "Iteration number(k) : " << k << endl;


	for (i = 0; i < nx + 1; i++) {
		delete[] T[i];
		delete[] TN[i];
	}
	delete[] T;
	delete[] TN;



	system("pause");
	return 33;
}