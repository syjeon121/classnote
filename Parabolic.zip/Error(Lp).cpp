#include "Error(Lp).h"
#include <iostream>
#include <cmath>
using namespace std;

double Error_Lp::Lp(int p, double *pArray1, double *pArray2, int n) {
	//p : the number of error
	//n : the number of node


	result = 0.0;
	sum = 0.0;
	int i;

	if (!p) cout << "Error! p is not netural number!" << endl;
		

	switch (p) {
	case 1:
		for (i = 0; i < n; i++) {
			sum = sum + abs(pArray1[i] - pArray2[i]);
		}

		result = sum / n;
		break;

	case 2:
		for (i = 0; i < n; i++) {
			sum = sum + pow(abs(pArray1[i] - pArray2[i]), 2);
		}

		result = sqrt(sum / n);
		break;

	case 33:
		double difference[3];
		double temp = 0.0;

		for (i = 0; i < n; i++) {
			difference[i] = abs(*pArray1 - *pArray2);
			if (difference[i] > temp) temp = difference[i];
		}
		
		result = temp;
		break;
	}

	
	
	return result;
}