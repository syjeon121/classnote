#pragma once
#include <iostream>
using namespace std;


class TDMA
{
public:
	double* X;
	double* B;

	double* a;
	double* b;
	double* c;

	double* c_prime;
	double* d_prime;

	void calX(int n, double* pa, double* pb, double* pc, double* pB);

};

