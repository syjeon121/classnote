#include <iostream>
#include <fstream>
#include "Error(Lp).h"
#include "TDMA.h"
using namespace std;

int main() {

	ofstream fout_exp("out_exp.dat");
	ofstream fout_semi("out_semi.dat");
	ofstream fout_imp("out_imp.dat");

	int j;

	const int ny = 40;
	double L = 0.04;
	double del_y = L / (double)ny;
	cout << "del_y = " << del_y << endl;
	double del_t = 0.000001;
	double nu = 0.5;

	double U_0 = 40.0;

	double U[ny + 1];
	double UN[ny + 1];

	double eps = pow(10, -5);
	double L2 = 1.0;
	Error_Lp error_Lp;

	int n = 1;
	const int print_step = 100;


	//Initial conditions
	for (j = 0; j < ny + 1; j++) {
		U[j] = 0.0;
		UN[j] = 0.0;
	}



	double mu = del_t*nu/pow(del_y, 2);
	cout << "mu = " << mu << endl << endl;
	double lambda;

	int nc;
	cout << "Choose the method!(1:explicit, 2:semi-implicit, 3:implicit)>> ";
	cin >> nc;

	//The variables for TDMA
	TDMA tdma;
	double a[ny - 1];
	double b[ny - 1];
	double c[ny - 1];
	double B[ny - 1];

	a[0] = 0.0;
	c[ny - 2] = 0.0;



	switch (nc) {
	case 1:

		lambda = 0.0;
		cout << "lambda = " << lambda << endl;

		while (L2 > eps) {

			

			//Boundary condition (j = 0)
			j = 0;
			UN[j] = U_0;

			//Boundary condition (j = ny)
			j = ny;
			UN[j] = 0.0;
			

			//Inner node
			for (j = 1; j < ny; j++) {
				UN[j] = (mu * U[j - 1]) + ((1.0 - 2.0 * mu) * U[j]) + (mu * U[j + 1]);
			}

			//Error
			L2 = error_Lp.Lp(2, U, UN, ny + 1);
			if (L2 > 100) {
				cout << "error! L2 > 100!" << endl; 
				return 0;
			}


			//Update
			for (j = 0; j < ny + 1; j++) {
				U[j] = UN[j];
			}

			//Print	
			if (n%print_step == 0) {
				fout_exp << endl;
				fout_exp << "variables = U Y" << endl;
				fout_exp << "zone j=" << ny + 1 << endl;
				for (j = 0; j < ny + 1; j++) fout_exp << U[j] << "\t" << j << endl;
			}
			
			n++;
		}
		break;
		
	case 2:

		lambda = 0.5;
		cout << "lambda = " << lambda << endl;

		while (L2 > eps) {

			//Boundary condition (j = 0)
			j = 0;
			UN[j] = U_0;

			//Boundary condition (j = ny)
			j = ny;
			UN[j] = 0.0;


			//Inner node(TDMA)
			for (j = 1; j < ny; j++) {
				if (j == 1) {
					b[j - 1] = 1.0 + mu;
					c[j - 1] = -mu / 2.0;
					B[j - 1] = (mu / 2.0 * U[j - 1]) + ((1.0 - mu) * U[j]) + (mu / 2.0 * U[j + 1]) + (mu*U_0 / 2.0);
				}
				else if (j == ny - 1) {
					a[j - 1] = -mu / 2.0;
					b[j - 1] = 1.0 + mu;
					B[j - 1] = (mu / 2.0 * U[j - 1]) + ((1.0 - mu) * U[j]) + (mu / 2.0 * U[j + 1]);
				}
				else {
					a[j - 1] = -mu / 2.0;
					b[j - 1] = 1.0 + mu;
					c[j - 1] = -mu / 2.0;
					B[j - 1] = (mu / 2.0 * U[j - 1]) + ((1.0 - mu) * U[j]) + (mu / 2.0 * U[j + 1]);
				}
			}

			
			tdma.calX(ny - 1, a, b, c, B);
			for (j = 1; j < ny; j++) {
				UN[j] = tdma.X[j - 1];
			}



			//Error
			L2 = error_Lp.Lp(2, U, UN, ny + 1);
			if (L2 > 100) {
				cout << "error! L2 > 100!" << endl;	
				system("pause");
				return 0;
			}

			//Update
			for (j = 0; j < ny + 1; j++) {
				U[j] = UN[j];
			}


			//Print	
			if (n%print_step == 0) {
				fout_semi << endl;
				fout_semi << "variables = U Y" << endl;
				fout_semi << "zone j=" << ny + 1 << endl;
				for (j = 0; j < ny + 1; j++) fout_semi << U[j] << "\t" << j << endl;
			}

			n++;
		}
		break;
		
	case 3:

		lambda = 1.0;
		cout << "lambda = " << lambda << endl;

		while (L2 > eps) {

			//Boundary condition (j = 0)
			j = 0;
			UN[j] = U_0;

			//Boundary condition (j = ny)
			j = ny;
			UN[j] = 0.0;


			//Inner node(TDMA)
			for (j = 1; j < ny; j++) {
				if (j == 1) {
					b[j - 1] = 1.0 + 2.0 * mu;
					c[j - 1] = -mu;
					B[j - 1] = U[j] + (mu*U_0);
				}
				else if (j == ny - 1) {
					a[j - 1] = -mu;
					b[j - 1] = 1.0 + 2.0 * mu;
					B[j - 1] = U[j];
				}
				else {
					a[j - 1] = -mu;
					b[j - 1] = 1.0 + 2.0 * mu;
					c[j - 1] = -mu;
					B[j - 1] = U[j];
				}
			}

			tdma.calX(ny - 1, a, b, c, B);
			for (j = 1; j < ny; j++) {
				UN[j] = tdma.X[j - 1];
			}



			//Error
			L2 = error_Lp.Lp(2, U, UN, ny + 1);
			if (L2 > 100) {
				cout << "error! L2 > 100!" << endl;	
				system("pause");
				return 0;
			}

			//Update
			for (j = 0; j < ny + 1; j++) {
				U[j] = UN[j];
			}

			//Print
			if (n%print_step == 0) {
				fout_imp << endl;
				fout_imp << "variables = U Y" << endl;
				fout_imp << "zone j=" << ny + 1 << endl;
				for (j = 0; j < ny + 1; j++) fout_imp << U[j] << "\t" << j << endl;
			}

			n++;
		}
		break;

	}


	cout << endl << "//-------------------------------//" << endl;
	cout << "Done!" << endl;
	cout << "Iteration number : " << n << endl;
	cout << "L2 error : " << L2 << endl;




	system("pause");
	return 33;
}