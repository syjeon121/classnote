#include "TDMA.h"
#include <iostream>
using namespace std;

void TDMA::calX(int n, double* pa, double* pb, double* pc, double* pB) {

	int i;

	//matrices of AX = B structure	
	X = new double[n];
	B = new double[n];
	for (i = 0; i < n; i++) {
		B[i] = pB[i];
	}

	//variables of A[a, b, c] structure
	a = new double[n];
	b = new double[n];
	c = new double[n];
	for (i = 0; i < n; i++) {
		a[i] = pa[i];
		b[i] = pb[i];
		c[i] = pc[i];
	}


	c_prime = new double[n - 1];
	d_prime = new double[n];
	a[0] = 0;
	c[n - 1] = 0;


	//calculation of c', d'
	for (i = 0; i < n; i++) {

		if (i == 0) {
			c_prime[i] = c[i] / b[i];
		}
		else if (i > 0 || i < n - 1) {
			c_prime[i] = c[i] / (b[i] - a[i] * c_prime[i - 1]);
		}


		if (i == 0) {
			d_prime[i] = B[i] / b[i];
		}
		else {
			d_prime[i] = (B[i] - a[i] * d_prime[i - 1]) / (b[i] - a[i] * c_prime[i - 1]);
		}
	}


	//calculation of X
	for (i = n - 1; i > -1; i--) {

		if (i == n - 1) {
			X[i] = d_prime[i];
		}

		X[i] = d_prime[i] - c_prime[i] * X[i + 1];
	}


}


