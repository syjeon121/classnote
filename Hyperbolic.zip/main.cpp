#include <iostream>
#include <cmath>
#include <fstream>
#include "TDMA.h"
using namespace std;

#define PI 3.1415926535897932384626433832795028841971


int main() {

	ofstream fout_U_init("U_init.dat");
	ofstream fout_U("U.dat");

	int nc = 0;										//1:Upwind, 2:Lax-Wendroff, 3:Crank-Nicolson 
	cout << "Choose scheme(1:Upwind, 2:Lax-Wendroff, 3:Crank-Nicolson) : ";
	cin >> nc;

	const int nx = 80;								//The number of grid in x direction
	double Lx = 400.0;								//Length in x direction
	double del_x = Lx / (double)nx;					//The grid step in x direction
	cout << "del_x = " << del_x << endl;


	double time = 0.0;
	double del_t = 0.02;							//The time step
	cout << "del_t = " << del_t << endl << endl;

	double U[nx + 1];						//The dependent variable at n step
	double UN[nx + 1];						//The dependent variable at n + 1 step

	double a_vel = 250.0;
	double b_vel = 0.0;
	double Cx = a_vel * del_t / del_x;
	cout << "Cx = " << Cx << endl;
	cout << "CFL number = " << Cx << endl << endl;

	const int print_step = 5;

	double A, B;
	int i, j, n;



	//Initial condtion
	for (i = 0; i < nx + 1; i++) {

		if ((i >= (50 / del_x)) && (i <= (110 / del_x)))
			U[i] = 100.0 * sin(PI * ((double)i * del_x - 50.0) / 60.0);
		else
			U[i] = 0.0;
	}

	fout_U << "variables = i U" << endl;
	fout_U << "zone i =" << nx << endl;
	for (i = 0; i < nx + 1; i++) {

		fout_U << i << "\t" << U[i] << endl;

	}
	fout_U << endl;


	switch (nc) {

	//Upwind scheme
	case 1:	
		for(n = 1; n < 100; n++){

			time = time + del_t;

			
			//Inner node
			for (i = 1; i < nx + 1; i++) {

				UN[i] = (1.0 - Cx) * U[i] + Cx * U[i - 1];
			
			}

			UN[0] = 0.0;
			UN[nx] = 0.0;
			//Update
			for (i = 0; i < nx + 1; i++) {

				U[i] = UN[i];

			}


			//Print
			if (n%print_step == 0) {
				fout_U << "variables = i U" << endl;
				fout_U << "zone i =" << nx << endl;
				for (i = 0; i < nx + 1; i++) {

						fout_U << i << "\t" << U[i] << endl;

				}
				fout_U << endl;
			}



		}
		break;
	}

	cout << "Done!" << endl;

	system("pause");
	return 33;
}